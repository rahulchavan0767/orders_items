# qwiklabs-ecommerce
This repository contains LookML files used in the Qwiklabs Looker instance. These files curate the default LookML projects and Explores for learners using a legacy Looker dataset contains sample retail logistics data about companies, their products, and customer/order information. 
